#!/bin/sh
set -e
npm install
npx cap add ios
npx cap sync ios
printf '\nJon AI iOS project created. Open it with: npx cap open ios\n'
