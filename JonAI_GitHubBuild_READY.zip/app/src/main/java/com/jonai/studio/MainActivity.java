package com.jonai.studio;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.webkit.*;
import android.view.View;
import android.graphics.Color;
import android.net.Uri;
import android.content.Intent;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.os.Environment;
import java.io.File;
import java.io.IOException;
import androidx.core.content.FileProvider;
import android.os.Build;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> uploadCallback;
    private PermissionRequest pendingPermissionRequest;
    private static final int FILE_CHOOSER = 42;
    private static final int PERMS = 43;
    private static final int CAMERA_PERMISSION = 44;
    private Uri cameraOutputUri;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(22, 22, 26));
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = cb;
                try {
                    // Image-only picker without capture -> open the Android Photo Picker
                    // instead of dropping the user into the generic Files app.
                    boolean imageOnly = false;
                    String[] types = p.getAcceptTypes();
                    if (types != null && types.length > 0) {
                        imageOnly = true;
                        for (String t : types) {
                            if (t != null && !t.isEmpty() && !t.equals("image/*")) { imageOnly = false; break; }
                        }
                    }
                    if (imageOnly && p.isCaptureEnabled()) {
                        launchCamera();
                        return true;
                    }
                    if (imageOnly && Build.VERSION.SDK_INT >= 33) {
                        Intent pick = new Intent(MediaStore.ACTION_PICK_IMAGES);
                        pick.setType("image/*");
                        pick.putExtra(MediaStore.EXTRA_PICK_IMAGES_MAX, Math.min(5, MediaStore.getPickImagesMaxLimit()));
                        startActivityForResult(pick, FILE_CHOOSER);
                        return true;
                    }
                    startActivityForResult(p.createIntent(), FILE_CHOOSER);
                    return true;
                } catch (Exception e) { uploadCallback=null; return false; }
            }
            @Override public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(() -> handleWebPermission(req));
            }
        });
        web.setWebViewClient(new WebViewClient());
        // Do NOT request camera/microphone on app startup. Android will ask only
        // when a WebView feature actually requests the corresponding resource.
        web.loadUrl("file:///android_asset/index.html");
    }

    private void launchCamera() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION);
            return;
        }
        try {
            Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (camera.resolveActivity(getPackageManager()) == null) { if (uploadCallback != null) uploadCallback.onReceiveValue(null); uploadCallback=null; return; }
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, "jonai_" + System.currentTimeMillis() + ".jpg");
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/JonAI");
                cameraOutputUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            } else {
                File dir = new File(getExternalCacheDir(), "camera");
                if (!dir.exists()) dir.mkdirs();
                File file = new File(dir, "jonai_" + System.currentTimeMillis() + ".jpg");
                cameraOutputUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
            }
            if (cameraOutputUri == null) throw new IOException("Не удалось создать файл камеры");
            camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraOutputUri);
            camera.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            startActivityForResult(camera, FILE_CHOOSER);
        } catch (Exception e) {
            if (uploadCallback != null) uploadCallback.onReceiveValue(null);
            uploadCallback=null; cameraOutputUri=null;
        }
    }

    private void handleWebPermission(PermissionRequest req) {
        if (req == null) return;
        String[] resources = req.getResources();
        java.util.ArrayList<String> needed = new java.util.ArrayList<>();
        for (String resource : resources) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource) &&
                    android.os.Build.VERSION.SDK_INT >= 23 &&
                    checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                if (!needed.contains(Manifest.permission.RECORD_AUDIO)) needed.add(Manifest.permission.RECORD_AUDIO);
            }
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource) &&
                    android.os.Build.VERSION.SDK_INT >= 23 &&
                    checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                if (!needed.contains(Manifest.permission.CAMERA)) needed.add(Manifest.permission.CAMERA);
            }
        }
        if (needed.isEmpty()) {
            req.grant(resources);
        } else if (android.os.Build.VERSION.SDK_INT >= 23) {
            pendingPermissionRequest = req;
            requestPermissions(needed.toArray(new String[0]), PERMS);
        } else {
            req.grant(resources);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION) {
            boolean ok = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (ok) launchCamera();
            else if (uploadCallback != null) { uploadCallback.onReceiveValue(null); uploadCallback=null; }
            return;
        }
        if (requestCode != PERMS || pendingPermissionRequest == null) return;
        PermissionRequest req = pendingPermissionRequest;
        pendingPermissionRequest = null;
        boolean ok = true;
        for (int result : grantResults) if (result != PackageManager.PERMISSION_GRANTED) ok = false;
        if (!ok) {
            try { req.deny(); } catch (Exception ignored) {}
            return;
        }
        try { req.grant(req.getResources()); } catch (Exception ignored) {}
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == FILE_CHOOSER && uploadCallback != null) {
            Uri[] result = null;
            if (cameraOutputUri != null) {
                if (resultCode == RESULT_OK) result = new Uri[]{cameraOutputUri};
                else if (Build.VERSION.SDK_INT >= 29) { try { getContentResolver().delete(cameraOutputUri, null, null); } catch (Exception ignored) {} }
                cameraOutputUri = null;
            } else if (resultCode == RESULT_OK && data != null) {
                java.util.ArrayList<Uri> uris = new java.util.ArrayList<>();
                if (data.getClipData() != null) {
                    android.content.ClipData cd = data.getClipData();
                    for (int i=0; i<cd.getItemCount() && uris.size()<5; i++) uris.add(cd.getItemAt(i).getUri());
                } else if (data.getData() != null) {
                    uris.add(data.getData());
                }
                if (!uris.isEmpty()) result = uris.toArray(new Uri[0]);
                else result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            }
            uploadCallback.onReceiveValue(result); uploadCallback=null;
        }
    }
    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
