Jon AI update system

App versions use normal semantic-style numbering:
1.0 -> 1.1 -> 1.3 -> 1.3 ...

Every release APK is signed with the same Jon AI release keystore so future versions can be installed over the previous version without uninstalling it.

IMPORTANT: keep app/keystore/jonai-release.jks safe. Losing this signing key means future APKs cannot update an installation signed with this key.
