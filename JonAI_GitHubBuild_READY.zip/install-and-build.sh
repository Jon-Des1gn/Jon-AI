#!/bin/sh
set -e

BASE="$HOME/jonai-build-tools"
JDK="$BASE/jdk17"
mkdir -p "$BASE"

if [ ! -x "$JDK/bin/java" ]; then
  echo "[1/3] Downloading JDK 17..."
  mkdir -p "$BASE/download"
  wget -q --show-progress -O "$BASE/download/jdk17.tar.gz" \
    "https://api.adoptium.net/v3/binary/latest/17/ga/linux/aarch64/jdk/hotspot/normal/eclipse"
  rm -rf "$JDK" "$BASE/jdk-extract"
  mkdir -p "$BASE/jdk-extract"
  tar -xzf "$BASE/download/jdk17.tar.gz" -C "$BASE/jdk-extract"
  mv "$BASE/jdk-extract"/* "$JDK"
  rm -rf "$BASE/jdk-extract"
fi

export JAVA_HOME="$JDK"
export PATH="$JAVA_HOME/bin:$PATH"

echo "[2/3] Java:"
java -version

echo "[3/3] Building JonAI APK..."
chmod +x ./gradlew
./gradlew assembleDebug

echo ""
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
