JonAI AndroidIDE - FIXED8

This version uses AndroidIDE's standard plugin DSL setup:
- Android Gradle Plugin 8.1.1
- compileSdk/targetSdk 34
- Java 17 compile compatibility
- No dependencyResolutionManagement block
- No buildscript classpath resolution

Open the project root (the folder containing settings.gradle, build.gradle and app/).
The JonAI web UI and MainActivity are unchanged.
