
(function(){
var T={
 dark:{'--bg':'#16161a','--bg-soft':'#1b1b20','--panel':'#202026','--panel-2':'#27272e','--panel-3':'#303038','--border':'#2c2c34','--border-2':'#3c3c46','--text':'#f5f5f7','--text-2':'#b3b3bd','--text-3':'#7c7c88','--accent':'#f5f5f7','--accent-ink':'#16161a','--user':'#2e2e36','--code-bg':'#101013','--glow':'rgba(255,255,255,.06)','--grid':'rgba(255,255,255,.03)','--shadow':'0 14px 40px rgba(0,0,0,.5)'},
 light:{'--bg':'#eef2f8','--bg-soft':'#f7f9fd','--panel':'#ffffff','--panel-2':'#eef1f7','--panel-3':'#dfe5ef','--border':'#d5dcea','--border-2':'#b9c4d8','--text':'#0d1526','--text-2':'#43506a','--text-3':'#7c8aa5','--accent':'#2563eb','--accent-ink':'#ffffff','--user':'#dbe7ff','--code-bg':'#0f172a','--glow':'rgba(37,99,235,.10)','--grid':'rgba(37,99,235,.05)','--shadow':'0 14px 40px rgba(37,99,235,.16)'}
};
try{
  var s=JSON.parse(localStorage.getItem('jonai_state_v11')||'null');
  var th=(s&&s.theme==='light')?'light':'dark';
  var el=document.documentElement;
  el.setAttribute('data-theme',th);
  var v=T[th]; for(var k in v){ el.style.setProperty(k,v[k]); }
}catch(e){}
})();
